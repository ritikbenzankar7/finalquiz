
let questions = [
    {
      numb: 1,
      question: "Short  means ?",
      answer: " Short is the qualifier ",
      options: [
        "Qualifier",
        " Short is the qualifier and int is the basic data type",
        "data type",
        "None of these"
        
  ]
    },
    {
      numb: 2,
      question: "Who invented C- langauge?",
      answer: "Dennis Ritchie",
      options: [
        "James Gausling",
        "Dennis Ritchie",
        "Bjarne Stroustrup",
        "None of these"
      ] 
        
    },
    {
      numb: 3,
      question: "Which keyword is used to prevent any changes in the variable within a C program? ",
      answer: "const",
      options: [
        "immutable",
        "int",
        "float",
        "const"
      ]
    },
    {
      numb: 4,
      question: "Which of the data types has the size that is variable? ",
      answer: "struct",
      options: [
        "struct",
        "int",
        "float",
        "double"
      ]
    },
    {  
      numb: 5,
      question: "Find out the correct order?",
      answer: "char < int < double",
      options: [
        "char < int < double",
        " int > char > float",
        "char > int > float",
        "double > char > int"
      ]
    },
    {
      numb: 6,
      question: "maximum value of unsigned interger when interger needs two bye of storage?",
      answer: "Tin and Lead",
      options: [
        " 2^16",
        " 2^16-1",
        "2^15-1",
        "None of these"
      ]
    },
    {
      numb: 7,
      question: "Which of the following is not a data types?",
      answer: "Real",
      options: [
        "Float",
        "Int",
        "Real",
        "Imaginery"
      ]
    },
    {
      numb: 8,
      question: " Enum types are processed by?",
      answer: "Compiler",
      options: [
        "Assembler",
        "Compiler",
        "Linker",
        "Pre-processor"
      ]
    },
    {
      numb: 9,
      question: "Select the statement which is not supported by C",
      answer: "String str;",
      options: [
        " Char str",
        " char *str;",
        "String str;",
        " float I;"
      ]
    },
    {
      numb: 10,
      question: "No of keywords in C?",
      answer: "32 Only",
      options: [
        "35 Only",
        "36 Only",
        "34 Only",
        "32 Only"
      ]
    }
  ];
  