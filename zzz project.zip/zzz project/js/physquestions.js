
let questions = [
    {
      numb: 1,
      question: "Which one of the following is electric conductor ?",
      answer: "Human body",
      options: [
        "A plastic shoe",
        "Distilled Water",
        "Human body",
        "None of these"
      ]
    },
    {
      numb: 2,
      question: " The buoyancy depends on?",
      answer: "The mass of the liquid displaced",
      options: [
        "The shape of the body",
        "The mass of the body",
        "The mass of the liquid displaced",
        "None of these"
      ]
    },
    {
      numb: 3,
      question: "Water boils at 212 degrees on which temperature scale?",
      answer: "Fahrenheit",
      options: [
        "Kelvin",
        "Fahrenheit",
        "Celsius",
        "None of these"
      ]
    },
    {
      numb: 4,
      question: "Pencil “lead” is made up of?",
      answer: "Lead",
      options: [
        "Oxide",
        "Lead",
        "Graphite",
        "None of these"
      ]
    },
    {
      numb: 5,
      question: "The Halley’s Comet will be visible again in the year?",
      answer: "2062 A.D.",
      options: [
        "2068 A.D.",
        "2062 A.D.",
        "2064 A.D.",
        "None of these"
      ]
    },
    {
      numb: 6,
      question: "Which two metals is pewter made from?",
      answer: "Tin and Lead",
      options: [
        "Copper and Bronze",
        "Tin and Lead",
        "Zinc and Gold",
        "None of these"
      ]
    },
    {
      numb: 7,
      question: "Convex lenses are used for the correction of?",
      answer: "Long-sightedness",
      options: [
        "Short-sightedness",
        "Long-sightedness",
        "Both",
        "None"
      ]
    },
    {
      numb: 8,
      question: "Light from the Sun reaches us in nearly?",
      answer: "8mins",
      options: [
        "8mins",
        "6mins",
        "4mins",
        "None"
      ]
    },
    {
      numb: 9,
      question: "Optical fibre works on the?",
      answer: "Total internal reflection",
      options: [
        "Principle of reflection",
        "Total internal reflection",
        "Interference",
        "None of these"
      ]
    },
    {
      numb: 10,
      question: "Red light is used in traffic signals because?",
      answer: "It has the longest wavelength",
      options: [
        "It has the longest wavelength",
        "visible to people with bad eye sight",
        "It is beautiful",
        "None of these"
      ]
    }
  ];
  