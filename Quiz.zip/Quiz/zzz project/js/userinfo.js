let user_name = sessionStorage.getItem("name");
document.querySelector("span.name").innerHTML = user_name;

